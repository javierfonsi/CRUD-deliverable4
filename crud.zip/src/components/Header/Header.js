import React from 'react';
import './Header.css'

export const Header = () => {
  return (
      <div className='header'>
          <strong><h1>C R U D E</h1></strong>
          <h3>Deliverable 4 - React Module</h3>
          <h4>By Javier Fonseca</h4>
      </div>
  )
};
